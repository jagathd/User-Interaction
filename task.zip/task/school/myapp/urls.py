from django.urls import path
from . import views

urlpatterns = [
    path('aboutus/', views.aboutusdata, name='about'),
    #path('register/', views.registerdata, name='register'),
    path('login/', views.logindata, name='login_url'),
    path('logout/', views.logoutdata, name='logout_url'),
    path('user_list/', views.user_list, name='test_json'),
    path('user_detail/<int:pk>/', views.user_detail, name='test_json_csrf')

]