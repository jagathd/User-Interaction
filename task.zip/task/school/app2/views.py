import json
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import Group, User
from django.core import serializers

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .forms import Signupform

from django.contrib import messages




def signupdata(request):
    if request.method == "POST":
        fm = Signupform(request.POST)
        if fm.is_valid():
            messages.success(request, 'Account created successfully')
            user = fm.save()
            group = Group.objects.get(name='student')
            #jsonData = serializers.serialize('json',group)
            #/print(group)
            user.groups.add(group)
    else:
        fm = Signupform()
    template = "register.html"
    return render(request, template, {'form': fm})


def logindatas(request):
    return hello

