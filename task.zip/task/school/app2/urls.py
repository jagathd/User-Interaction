from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signupdata, name='signups'),
    path('logins/', views.logindatas, name='logins'),
]