from django.db import models
from django.utils import timezone
from datetime import datetime
from django.contrib.auth.models import User
# Create your models here.

class Queries(models.Model):
    question = models.TextField()
    file = models.FileField()
    queries_by = models.ManyToManyField(User, related_name='queries_user')

class Answer(models.Model):
    answer = models.TextField(blank=True, default=None)
    created_user = models.ForeignKey(Queries, on_delete=models.CASCADE)