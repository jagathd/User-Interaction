from django import forms
from .models import Queries,Answer

class MyuserForm(forms.ModelForm):
    class Meta:
        model = Queries
        fields = ['question', 'queries_by', 'file']

class MyAnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ['answer','created_user']