from django.urls import path
from . import views

urlpatterns = [
    path('test/', views.test, name='create_query'),
    path('newquery/', views.createnewquery, name='create_query'),
    path('answer/', views.answerforquery, name='answer_query'),
    path('userqueries/', views.viewuserqueries, name='user_query_answer'),
    path('viewqueries/', views.viewuser, name='view_user'),
    path('updateuser/<int:ids>/', views.updateuser, name='update_user'),
    path('deleteuser/<int:ids>/', views.deleteuser, name='delete_user'),
]