from django.contrib import admin
from .models import Answer, Queries

# Register your models here.
admin.site.register(Queries)
#admin.site.register(Answer)

