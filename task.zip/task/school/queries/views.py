import json
from django.core import serializers
from django.http import HttpResponse
from django.shortcuts import render
from .forms import MyuserForm,MyAnswerForm
from .models import Queries,Answer
from django.contrib.auth.models import Group, User
from django.db import connection

from rest_framework import viewsets
from rest_framework import permissions
from .serializers import UserSerializer, GroupSerializer, QueriesSerializer

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db import connection
import datetime
import os
# Create your views here.
permission_classes = (IsAuthenticated,)

def createnewquery(request):
    initialdata = {
        'queries_by': request.user.id,
        'answer': ''
    }
    if request.method == 'POST':
        form = MyuserForm(request.POST, request.FILES)
        if form.is_valid():
            f = request.FILES['file']
            #f = form.file
            print(f)
            if f is not None:
                resfile = str(f)
                """now = datetime.datetime.now()
                curtime = str(now.year) + str(now.month) + str(now.day) + str(now.hour) + str(now.minute) + str(now.second)
                resfile = str(curtime) + str(f)                
                user_pr = form.save(commit=False)
                user_pr.file = resfile
                user_pr.queries_by = user_pr.id
                user_pr.save()
                print(user_pr.id)"""

                with open('media/' + resfile, 'wb+') as destination:
                    for chunk in f.chunks():
                        destination.write(chunk)
                form.save()
            # return render(request, 'about_us.html')
            return viewuserqueries(request)

    else:
        form = MyuserForm(initial=initialdata)

    return render(request, 'add_query.html', {'form': form, 'data': 'query'})


def viewuser(request):
    form = MyAnswerForm(request.POST or None)
    if form.is_valid():
        form.save()
    users = Queries.objects.all().order_by('-id')
    answ = Answer.objects.all()
    json_res = []
    for x in users:
        json_obj = dict(data=x)
        for y in answ:
            if x.id == y.created_user.id:
                json_obj['myproperty'] = y

        json_res.append(json_obj)

    context = {
        "form": form,
        "users": json_res,
        "act": "dash",
    }
    return render(request, 'all_queries.html', context)

def updateuser(request, ids):
    iddata = Queries.objects.get(id=ids)
    formQ = MyuserForm(request.POST or None, instance=iddata)
    formA = MyAnswerForm(request.POST or None, instance=iddata)
    if request.method == "POST":
        formA = MyAnswerForm(request.POST)
        if formA.is_valid():
            formA.save()
            return render(request, 'about_us.html')
        else:
            print('form not valid')

    users = Queries.objects.all().order_by('-id')
    answ = Answer.objects.all()
    json_res = []
    for x in users:
        json_obj = dict(data=x)
        for y in answ:
            if x.id == y.created_user.id:
                json_obj['myproperty'] = y

        json_res.append(json_obj)

    context = {
        "form": formQ,
        "ans":formA,
        "users": json_res,
        "ansD": answ,
        "act": "edit",
        "iddata": iddata,
        "ospath": os.getcwd()
    }
    return render(request, 'all_queries.html', context)


def deleteuser(request, ids):
    userdata = Queries.objects.get(id=ids)
    userdata.delete()
    users = Queries.objects.all()
    context = {
        "users": users
    }
    return render(request, 'all_queries.html', context)


def answerforquery(request):
    initialdata = {
        'answered_by': request.user.id,
    }
    if request.method == 'POST':
        form = MyuserForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'about_us.html')

    else:
        form = MyuserForm(initial=initialdata)

    return render(request, 'add_query.html', {'form': form, 'data': 'answer'})


def viewuserqueries(request):
    users = Queries.objects.all().filter(queries_by=request.user.id).order_by('-id')
    answ = Answer.objects.all()
    json_res = []
    for x in users:
        json_obj = dict(data=x)
        for y in answ:
            if x.id == y.created_user.id:
                json_obj['myproperty'] = y

        json_res.append(json_obj)
    #print(json_res)

    context = {
        "users": json_res,
        "act": "dash"
    }
    return render(request, 'user_questions_answer.html', context)

def test(request):
    print(os.getcwd())
    return HttpResponse('hello')

class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [permissions.IsAuthenticated]

class Questionsdata(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Queries.objects.all()
    serializer_class = QueriesSerializer
    permission_classes = [permissions.IsAuthenticated]

